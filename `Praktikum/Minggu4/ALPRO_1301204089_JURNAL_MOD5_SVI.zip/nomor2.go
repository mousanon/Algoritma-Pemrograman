package main

import "fmt"

func main() {
	var i, n, bobot, sks int
	var nilai string
	var jum_sks, jum int

	fmt.Scanln(&n)
	jum := 0
	jum_sks := 0
	i := 1
	for i <= n {
		fmt.Scanln(&nilai, &sks)
		for 
	}
}