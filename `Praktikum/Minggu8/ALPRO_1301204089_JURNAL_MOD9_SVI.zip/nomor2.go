package main

import "fmt"

const NMAX int = 127
type tabel [NMAX]string

func isiArray(t *tabel, n *int) {
	var arr string
	fmt.Scan(&arr)
	*n = 0
	for arr != "." {
		t[*n] = arr
		*n = *n + 1
		fmt.Scan(&arr)
	}
}

func cetakArray(t tabel, n int){
	for i := 0; i < n; i++ {
		if t[i] != "" {
			fmt.Print(t[i])
		}
	}
}

func balikanArray(t *tabel, n int) {
	var awal int = 0
	var akhir int = n - 1
	var temp string
	for awal < n / 2 {
		temp = t[awal]
		t[awal] = t[akhir]
		t[akhir] = temp

		awal++
		akhir--
	}
}

func palindrom(t tabel, n int) bool {
	var arrayBalik tabel
	var hasil bool
	hasil = true
	arrayBalik = t


	balikanArray(&arrayBalik, n)
	cetakArray(arrayBalik, n)
	for i := 0; i < n; i++ {
		if arrayBalik != t[i] {
			hasil = false
		}
	}
	return hasil
}

func main() {
	var data tabel
	var n int

	n = 0
	isiArray(&data, &n)
	fmt.Println("Palindrom?", palindrom(data, NMAX))
}