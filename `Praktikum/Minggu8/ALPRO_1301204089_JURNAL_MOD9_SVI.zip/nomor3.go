package main

import "fmt"

const NBUKU int = 5

type buku struct {
	judul string
	penulis string
	tahun int
}

type TabBuku[NBUKU]buku

func tambahkanBuku(kardus *TabBuku, atas *int) {
	var n int

	fmt.Scanln(&n)

	for i := 0; i < n; i++ {
		fmt.Print("Masukkan Judul: ")
		fmt.Scanln(&kardus[i].judul)
		fmt.Print("Masukkan Penulis: ")
		fmt.Scanln(&kardus[i].penulis)
		fmt.Print("Masukkan tahun: ")
		fmt.Scanln(&kardus[i].tahun)
		*atas++
	}
}

func ambilBuku(kardus *TabBuku, atas *int, ambil *buku) {
	*ambil = kardus[*atas]
	*atas--
}

func cariBuku(kardus *TabBuku, atas *int, x string) {
	var ketemu bool = false
	for !ketemu {
		if x != kardus[*atas].judul {
			fmt.Println(kardus[*atas].judul)
		} else if x == kardus[*atas].judul {
			fmt.Println("KETEMU")
			ketemu = true
		}
		*atas--
	}
}

func main() {
	var atas int
	var kardus TabBuku
	var hasilCari buku

	atas = 0

	for i:= 0; i < 4; i++ {
		fmt.Print("Bukku ke", i, "\n")
		tambahkanBuku(&kardus, &atas)
	}

	fmt.Print("Proses cari buku")
	cariBuku(&kardus, &atas, &hasilCari)
}