package main

import "fmt"

const N int = 90
type tabGol = [N]int

func inputData(t *tabGol, n *int) {
	var arr int
	fmt.Scan(&arr)
	*n = 0
	for arr >= 0 && *n <= 100 {
		t[*n] = arr
		*n++
		fmt.Scan(&arr)
	}
}

func rataan(t tabGol, n int) float64 {
	var total int
	var rata float64
	total = 0

	for i := 0; i < n; i++ {
		total += t[i]
	}

	rata = float64(total) / float64(n)

	return rata
}

func main() {
	var (
		t tabGol
		n int
		tim1, tim2, tim3 float64
	)

	for i := 1; i <= 3; i++ {
		fmt.Println("Tim", i, ":")
		inputData(&t, &n)
		if i == 1 {
			tim1 = rataan(t, n)
		} else if i == 2 {
			tim2 = rataan(t, n)
		} else if i == 3 {
			tim3 = rataan(t, n)
		}
	}
	fmt.Println(tim1, tim2, tim3)
}